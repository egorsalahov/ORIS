﻿using MiniTemplateEnginge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniTemplateEngingeUnitTests
{
    [TestClass]
    public class HtmlTemplateRenderTests
    {
        [TestMethod]
        public void RenderFromString_When_Return()
        {

            //Arrange

            var testee = new HtmlTemplateRenderer();
            string templateHtml = "<h1>Привет, ${name}</h1>";
            var model = new { Name = "Тимерхан" };
            string exceptedString = "<h1>Привет, Тимерхан</h1>";

            //Act
            var result = testee.RenderFromString(templateHtml, model);

            //Assert
            Assert.AreEqual(exceptedString, result);
        }

        [TestMethod]
        public void RenderFromString_WhenDouble_ReturnCorrectString()
        {

            //Arrange

            var testee = new HtmlTemplateRenderer();
            string templateHtml = "<h1>Привет, ${Name}</h1> <p>Привет, ${Name}</p>";
            var model = new { Name = "Тимерхан"};
            string exceptedString = "<h1>Привет, Тимерхан</h1> <p>Привет, Тимерхан</p>";

            //Act
            var result = testee.RenderFromString(templateHtml, model);

            //Assert
            Assert.AreEqual(exceptedString, result);
        }

        [TestMethod]
        public void RenderFromString_WhenTwoProperties_ReturnCorrectString()
        {

            //Arrange

            var testee = new HtmlTemplateRenderer();
            string templateHtml = "<h1>Привет, ${Name}</h1> <p>Привет, ${Email}</p>";
            var model = new { Name = "Тимерхан", Email = "test@test.ru" };
            string exceptedString = "<h1>Привет, Тимерхан</h1> <p>Привет, test@test.ru</p>";

            //Act
            var result = testee.RenderFromString(templateHtml, model);

            //Assert
            Assert.AreEqual(exceptedString, result);
        }



        [TestMethod]
        public void RenderFromString_WhenSubProperties_ReturnCorrectString()
        {

            //Arrange

            var testee = new HtmlTemplateRenderer();
            string templateHtml = "<h1>Привет, ${name}</h1> <p> Группа: ${Group.Name} Привет, ${Email}</p>";
            var model = new { Name = "Тимерхан", Email = "test@test.ru", Group = new { Id = 1, Name = "11-409" } };
            string exceptedString = "<h1>Привет, Тимерхан</h1> <p> Группа: 11-409 Привет, test@test.ru</p>";

            //Act
            var result = testee.RenderFromString(templateHtml, model);

            //Assert
            Assert.AreEqual(exceptedString, result);
        }

        [TestMethod]
        public void RenderFromString_WhenIf_ReturnsCorrectString()
        {
            //Arrange

            var testee = new HtmlTemplateRenderer();
            string testData = "<h1>$if (Name == Dima) <p>Привет, Дима</p> $else <p>Привет, анониим</p></h1>";
            var model = new { Name = "Тимерхан", Email = "test@test.ru", Group = new { Id = 1, Name = "11-409" } };
            string exceptedString = "<h1>Привет, Тимерхан</h1> <p> Группа: 11-409 Привет, test@test.ru</p>";

            //Act
            var result = testee.RenderFromString(templateHtml, model);

            //Assert
            Assert.AreEqual(exceptedString, result);
        }
    }
}
