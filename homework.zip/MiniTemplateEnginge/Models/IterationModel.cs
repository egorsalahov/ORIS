﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniTemplateEnginge.Models
{
    public class IterationModel
    {
        public string PropertyName { get; set; } = String.Empty;

        public string CollectionPath { get; set; } = String.Empty;
    }
}
